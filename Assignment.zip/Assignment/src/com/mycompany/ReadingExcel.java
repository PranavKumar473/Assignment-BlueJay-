package com.mycompany;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

class Employee {
	private String name;
	private String position;
	private long hoursWorked;
	private int consecutiveDays;
	private double timeBetweenShifts;

	public Employee(String name, String position, long hoursWorked) {
		this.name = name;
		this.position = position;
		this.hoursWorked = hoursWorked;
	}

	public String getName() {
		return name;
	}

	public String getPosition() {
		return position;
	}

	public long getHoursWorked() {
		return hoursWorked;
	}

	public int getConsecutiveDays() {
		return consecutiveDays;
	}

	public void setConsecutiveDays(int consecutiveDays) {
		this.consecutiveDays = consecutiveDays;
	}

	public double getTimeBetweenShifts() {
		return timeBetweenShifts;
	}

	public void setTimeBetweenShifts(double timeBetweenShifts) {
		this.timeBetweenShifts = timeBetweenShifts;
	}
}

public class ReadingExcel {

	public static void main(String[] args) throws IOException, ParseException {
		String excelFilePath = "C:\\Users\\prana\\Documents\\workspace-spring-tool-suite-4-4.19.0.RELEASE\\Assignment\\datafiles\\Assignment_Timecard.xlsx";

		FileInputStream inputStream = new FileInputStream(excelFilePath);

		// we create an XSSF Workbook object for our XLSX Excel File
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

		// we get first sheet
		XSSFSheet sheet = workbook.getSheet("Sheet1");

		int lrow = sheet.getLastRowNum();// This will return the last row number that is exactly equal to number of
											// rows.

		// Map to store the end time of the previous shift for each employee.
		// This will be used to calculate the time between consecutive shifts.

		Map<String, Date> prevShiftEndTime = new HashMap<>();

		// Map to track the number of consecutive days worked by each employee.
		// This information is used to identify employees who have worked for 7
		// consecutive days.

		Map<String, Integer> consecutiveDays = new HashMap<>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		List<Employee> employees = new ArrayList<>(); // List to store Employee objects

		for (int r = 1; r <= lrow; r++) {
			Row row = sheet.getRow(r); // Retrieve the current row from the Excel sheet.

			String employeeName = row.getCell(7).getStringCellValue();// Retrieve the employee's name from cell at index
																		// 7.
			String position = row.getCell(0).getStringCellValue(); // Retrieve the employee's position from cell at
																	// index 0.
			
			Cell timeInCell = row.getCell(2); // Get the cell containing the time-in information from index 2.
			
			Cell timeOutCell = row.getCell(3); // Get the cell containing the time-out information from index 3

			if (timeInCell == null || timeOutCell == null)
			// Check if either the time-in cell or time-out cell is null.
			// If either is null, skip processing this row and continue to the next row.
			{
				continue;
			}

			String timeInValue;
			String timeOutValue;

			// Handle the time-in cell's value
			if (timeInCell.getCellType() == CellType.NUMERIC) {
				if (DateUtil.isCellDateFormatted(timeInCell)) {
					// If the cell contains a date value, format it using dateFormat
					Date date = timeInCell.getDateCellValue();
					 // If the cell contains a numeric value, convert it to text
					timeInValue = dateFormat.format(date);
				} else {
					timeInValue = NumberToTextConverter.toText(timeInCell.getNumericCellValue());
				}
			} else if (timeInCell.getCellType() == CellType.STRING) {
				// If the cell is of string type, use its string value
				timeInValue = timeInCell.getStringCellValue();
			} else {
				 // Skip processing for unsupported cell types
				continue;
			}

			// Processing time out cell
			if (timeOutCell.getCellType() == CellType.NUMERIC) {
				// Check if the numeric cell contains a date or a general numeric value
				if (DateUtil.isCellDateFormatted(timeOutCell)) {
					// Convert date cell to formatted date string
					Date date = timeOutCell.getDateCellValue();
					// Convert general numeric cell to text
					timeOutValue = dateFormat.format(date);
				} else {
					timeOutValue = NumberToTextConverter.toText(timeOutCell.getNumericCellValue());
				}
			} else if (timeOutCell.getCellType() == CellType.STRING) {
				timeOutValue = timeOutCell.getStringCellValue();
			} else {
				 // Skip unsupported cell types
				continue;
			}

			// Check if either timeInValue or timeOutValue is empty
			if (timeInValue.isEmpty() || timeOutValue.isEmpty()) {
				// Skip processing for this row
				continue;
			}

			// Parse time in and time out values into Date objects
			Date timeIn = dateFormat.parse(timeInValue);
			Date timeOut = dateFormat.parse(timeOutValue);

			// Calculate hours worked for the current shift
			long hoursWorked = (timeOut.getTime() - timeIn.getTime()) / (1000 * 60 * 60);

			// Create an Employee object
			Employee employee = new Employee(employeeName, position, hoursWorked);
			employees.add(employee);

			// Processing for subsequent shifts
			if (!prevShiftEndTime.containsKey(employeeName)) {
				prevShiftEndTime.put(employeeName, timeOut);
				continue; // Skip further processing for the first shift
			}

			// Calculate time between shifts
			long timeBetweenShiftsMillis = timeIn.getTime() - prevShiftEndTime.get(employeeName).getTime();
			double timeBetweenShiftsHours = timeBetweenShiftsMillis / (60 * 60 * 1000);

			// Check if the employee is already in the consecutiveDays map

			if (consecutiveDays.containsKey(employeeName)) {
				int days = consecutiveDays.get(employeeName);

				 // Check if time between shifts is less than 24 hours
				if (timeBetweenShiftsHours < 24) {
					days++;
				} else {
					days = 1;
				}
				consecutiveDays.put(employeeName, days);

				 // Check if the employee has worked for 7 consecutive days
				if (days >= 7) {
					employee.setConsecutiveDays(days);
				}
			} else {
				// If the employee is not in the map, add them with 1 day of consecutive work
				consecutiveDays.put(employeeName, 1);
			}

			// Check for less than 10 hours between shifts
			if (timeBetweenShiftsHours > 1 && timeBetweenShiftsHours < 10) {
				System.out.println("Name: " + employee.getName() + ", Position: " + employee.getPosition()
						+ " - Less than 10 hours between shifts");
			}

			prevShiftEndTime.put(employeeName, timeOut);
		}

		// Sort employees based on the order of your requirements
		employees.sort(Comparator.comparing(Employee::getConsecutiveDays, Comparator.reverseOrder())
				.thenComparing(Employee::getTimeBetweenShifts)
				.thenComparing(Employee::getHoursWorked, Comparator.reverseOrder()));

		// Display employees in the desired order
		for (Employee employee : employees) {
			if (employee.getConsecutiveDays() >= 7) {
				System.out.println("Name: " + employee.getName() + ", Position: " + employee.getPosition()
						+ " - Worked for 7 consecutive days");
			}
		}
		for (Employee employee : employees) {
			if (employee.getHoursWorked() > 14) {
				System.out.println("Name: " + employee.getName() + ", Position: " + employee.getPosition()
						+ " - Worked for more than 14 hours in a single shift");
			}
		}

		workbook.close();
	}
}
